<?php  

error_reporting(0);
?>

     <html lang="en">
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> </title>

    <link rel="stylesheet" type="text/css" href="style/bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="style/font-awesome/css/font-awesome.min.css" />
    <link rel="stylesheet" type="text/css" href="style/css/local.css" />
    
	<link href="style/css/table-responsive.css" rel="stylesheet" media="screen">
    <script type="text/javascript" src="admin/bootstraps/jquery.min.js"></script>
    <script type="text/javascript" src="style/js/jquery-1.12.0.min.js"></script>
    <script type="text/javascript" src="style/bootstrap/js/bootstrap.min.js"></script>
   
	<link rel="stylesheet" href="style/text_area/css/site.css">
    <link rel="stylesheet" href="style/text_area/src/richtext.min.css">
    <script src="style/text_area/src/jquery.richtext.js"></script>

	<script src="style/js/bootstrap-select.min.js"></script>

</head>		
		<br><br>
        <br><br>
        <br><br>
        <br><br>
        <br><br>
        <br><br>
	
    <table align='center'> <tr><td><div class='col-md-12 content'>
<div class='panel panel-default'>
<div class='panel-heading'>
		<h4>Pajina Login</h4>
</div>
	<div class='panel-body'>
	
		<!-- 	<div class='row'>
  	<h5 class='text-success text-center'><b>Pajina Login</b></h5> -->
    <center>
		<form class='form-horizontal'method='Post'action='cek_login.php' enctype='multipart/form-data'>
			<fieldset>
			

   <div class='form-group'>
				<label class='control-label col-sm-5' for='id_gasto'>Username :</label>
				<div class='col-sm-12'>
                <center>
					<input type='text' name='username' class='form-control' />
                    </center>
				</div>
			</div>
            
             <div class='form-group'>
				<label class='control-label col-sm-5' for='id_gasto'>Password :</label>
				<div class='col-sm-12'>
					<input type='password' name='password' class='form-control' />
				</div>
			</div>				
			
					<button type='submit' class='btn btn-success'name = 'prosses'value ='login'>Login</button>				
			
			</div>
			</div>
		
			</fieldset>
		</form>
        
        <?php if($_GET['error']){echo"<center><font color ='red'>Login Falha</font></center>"; }?>
          </center>
	</div>
    
    </div>
    <td></tr></table>

<link href="../../style/css/bootstrap-datetimepicker.min.css" rel="stylesheet" media="screen">
<script type="text/javascript" src="../../style/js/bootstrap-datetimepicker.js" charset="UTF-8"></script>

</body>
</html>
