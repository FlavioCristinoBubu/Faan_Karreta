<?php
include'admin/include/class.php';
$login = new login();
 $cek=$login->login_utilizador($_POST['username'],$_POST['password']);
 if($cek) {
 header('location:admin/media.html');
  
  } else {
      header('location:index.php?error=koko');
}

?>