<?php


echo"<ul class='nav navbar-nav navbar-left navbar-user'>";
echo"
<ul class='nav navbar-nav navbar-left navbar-user'>
"; 



	
	if ($_GET['pagina']=='kliente') { echo "<li class='active'><a href='kliente.html'><i class='glyphicon glyphicon-list'></i>&nbsp  kliente</a></li>"; }
    else { echo "<li><a href='kliente.html'><i class='glyphicon glyphicon-list'></i>&nbsp kliente </a></li>"; }

    
    	if ($_GET['pagina']=='sosa') { echo "<li class='active'><a href='sosa.html'><i class='glyphicon glyphicon-list'></i>&nbsp  Sosa</a></li>"; }
    else { echo "<li><a href='sosa.html'><i class='glyphicon glyphicon-list'></i>&nbsp osan-tama </a></li>"; }

    
    	if ($_GET['pagina']=='gasto') { echo "<li class='active'><a href='gasto.html'><i class='glyphicon glyphicon-list'></i>&nbsp Gasto</a></li>"; }
    else { echo "<li><a href='gasto.html'><i class='glyphicon glyphicon-list'></i>&nbsp Gasto </a></li>"; }

    
    
	

	echo" </ul></ul>

	<ul class='nav navbar-nav navbar-right navbar-user'>
       <li class='dropdown user-dropdown'>
        <a href='#' class='dropdown-toggle' data-toggle='dropdown'><i class='fa fa-user'></i>$_SESSION[naran_utilizador]<b class='caret'></b></a>
            <ul class='dropdown-menu'>
 
                <li><a href='../index.php'><i class='fa fa-power-off'></i>Log Out</a></li>
            </ul>
        </li>
    </ul>";
	?>