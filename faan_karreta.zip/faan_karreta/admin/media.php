<?php ob_start(); ?>
<?php

error_reporting(0);
//  session_start();

include'include/class.php';


     
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> </title>

    <link rel="stylesheet" type="text/css" href="../style/bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="../style/font-awesome/css/font-awesome.min.css" />
    <link rel="stylesheet" type="text/css" href="../style/css/local.css" />
    
	<link href="style/css/table-responsive.css" rel="stylesheet" media="screen">
    <script type="text/javascript" src="bootstraps/jquery.min.js"></script>
    <script type="text/javascript" src="../style/js/jquery-1.12.0.min.js"></script>
    <script type="text/javascript" src="../style/bootstrap/js/bootstrap.min.js"></script>
   
	<link rel="stylesheet" href="../style/text_area/css/site.css">
    <link rel="stylesheet" href="../style/text_area/src/richtext.min.css">
    <script src="../style/text_area/src/jquery.richtext.js"></script>

	<script src="../style/js/bootstrap-select.min.js"></script>

</head>
<body> 
				<center><img src="img/karreta.jpeg" height="500px" width=" 500px  "class="img-responsive"></center>          

	<nav class="navbar navbar-inverse">            
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" >Sistema Gestaun Orsamentu Faan-Karreta</a>
            </div>
            <div class="collapse navbar-collapse navbar-ex1-collapse">
            <?php include("menu_top.php");?>
            </div>
    </nav>
	
   
    <div id="page-wrapper">
            <div class="row"> <div id="wrapper">
			
                <?php 
				
			
				include("content.php"); ?>
            </div>
			 </div>
            <!-- /.row -->
    </div>


<!-- chosen -->
<link rel="stylesheet" href="css/chosen.css">
<style type="text/css" media="all">
    /* fix rtl for demo */
    .chosen-rtl .chosen-drop { left: -9000px; }
</style>
<script src="bootstraps/chosen.jquery.js" type="text/javascript"></script> 
<!-- chosen -->
<script type="text/javascript">
    var config = {
      '.chosen-select'           : {},
      '.chosen-select-deselect'  : {allow_single_deselect:true},
      '.chosen-select-no-single' : {disable_search_threshold:10},
      '.chosen-select-no-results': {no_results_text:'Oops, nothing found!'},
      '.chosen-select-width'     : {width:"95%"}
    }
    for (var selector in config) {
      $(selector).chosen(config[selector]);
    }
</script>
<!-- dataTables -->
<link rel="stylesheet" type="text/css" href="../style/bootstrap/css/dataTables.bootstrap.css">
<script type="text/javascript" language="javascript" src="../style/js/jquery.dataTables.js"> </script>
<script type="text/javascript" language="javascript" src="../style/js/dataTables.bootstrap.js"></script>
<script type="text/javascript" language="javascript" class="init">
    $(document).ready(function() {
        $('#example').DataTable();
		$('#example1').DataTable();
    } );
    </script>
	
<!-- datepicker	-->
	<link href="../style/css/bootstrap-datetimepicker.min.css" rel="stylesheet" media="screen">
	<script src="../style/js/bootstrap-datepicker.js"></script>
	<script type="text/javascript">
	if (top.location != location) {
    top.location.href = document.location.href ;
  }
		$(function(){
			window.prettyPrint && prettyPrint();
			$('#dp1').datepicker({
				format: 'yyyy-mm-dd'
			});
			$('#dp2').datepicker();
			$('#dp3').datepicker();
			$('#dp3').datepicker();
			$('#dpYears').datepicker();
			$('#dpMonths').datepicker();
			
			
			var startDate = new Date(2012,1,20);
			var endDate = new Date(2012,1,25);
			$('#dp4').datepicker()
				.on('changeDate', function(ev){
					if (ev.date.valueOf() > endDate.valueOf()){
						$('#alert').show().find('strong').text('The start date can not be greater then the end date');
					} else {
						$('#alert').hide();
						startDate = new Date(ev.date);
						$('#startDate').text($('#dp4').data('date'));
					}
					$('#dp4').datepicker('hide');
				});
			$('#dp5').datepicker()
				.on('changeDate', function(ev){
					if (ev.date.valueOf() < startDate.valueOf()){
						$('#alert').show().find('strong').text('The end date can not be less then the start date');
					} else {
						$('#alert').hide();
						endDate = new Date(ev.date);
						$('#endDate').text($('#dp5').data('date'));
					}
					$('#dp5').datepicker('hide');
				});

        // disabling dates
        var nowTemp = new Date();
        var now = new Date(nowTemp.getFullYear(), nowTemp.getMonth(), nowTemp.getDate(), 0, 0, 0, 0);

        var checkin = $('#dpd1').datepicker({
          onRender: function(date) {
            return date.valueOf() < now.valueOf() ? 'disabled' : '';
          }
        }).on('changeDate', function(ev) {
          if (ev.date.valueOf() > checkout.date.valueOf()) {
            var newDate = new Date(ev.date)
            newDate.setDate(newDate.getDate() + 1);
            checkout.setValue(newDate);
          }
          checkin.hide();
          $('#dpd2')[0].focus();
        }).data('datepicker');
        var checkout = $('#dpd2').datepicker({
          onRender: function(date) {
            return date.valueOf() <= checkin.date.valueOf() ? 'disabled' : '';
          }
        }).on('changeDate', function(ev) {
          checkout.hide();
        }).data('datepicker');
		});
	</script>
	<script type="text/javascript">
_uacct = "UA-106117-1";
urchinTracker();
</script>
<script type="text/javascript">
    $(document).ready(function() {
        $('.text_area').richText();
        $('.text_area1').richText();
	   $('.text_area2').richText();
    });
</script>
<script type="text/javascript">
    $(function(){
    $("#compose-texarea").wysihtml5();
    });
</script>
</body>
</html>
<?phpob_end_clean();?>
