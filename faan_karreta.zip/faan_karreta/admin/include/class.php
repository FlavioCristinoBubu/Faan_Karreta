<?php 

//Class No ba dados  Zona
	class kliente {
	function hare_kliente(){
			$con = mysqli_connect("localhost","root","");
            mysqli_select_db($con,"faan_karreta");
			$query=mysqli_query($con,"Select * from  tb_kliente") or die ("".mysqli_error());
			while($row=mysqli_fetch_array($query))
				$data[]=$row;
			  return $data;
	}
	
			function Rai_kliente($id_kliente,$naran_kliente,$kontak,$kategorio_kliente){
				$con = mysqli_connect("localhost","root","");
            mysqli_select_db($con,"faan_karreta");
			$query= mysqli_query($con,"INSERT into tb_kliente values('$id_kliente','$naran_kliente','$kontak','$kategorio_kliente')");
			return $query;
		}
		
		function Manipula_kliente($id_kliente){
			$con = mysqli_connect("localhost","root","");
            mysqli_select_db($con,"faan_karreta");
			$query=mysqli_query($con,"Select * from tb_kliente where id_kliente='$id_kliente'") or die ("".mysqli_error());
			while($row=mysqli_fetch_array($query))
				$data[]=$row;
			  return $data;
		}
		
			function update_kliente($id_kliente,$naran_kliente,$kontak,$kategorio_kliente){
			$con = mysqli_connect("localhost","root","");
            mysqli_select_db($con,"faan_karreta");
			$query= mysqli_query($con,"Update tb_kliente set naran_kliente ='$naran_kliente', kontak='$kontak',kategorio_kliente='$kategorio_kliente' where id_kliente='$id_kliente'");
			return $query;
			
		}
		
		
				function Apaga_kliente($id_kliente) {
			$con = mysqli_connect("localhost","root","");
            mysqli_select_db($con,"faan_karreta");
			$query=mysqli_query($con,"DELETE FROM tb_kliente WHERE id_kliente='$id_kliente'") or die ("".mysqli_error());
			return $query;    
		}
		
	
	}
    
    
    
    class sosa {
	function hare_sosa(){
			$con = mysqli_connect("localhost","root","");
            mysqli_select_db($con,"faan_karreta");
			$query=mysqli_query($con,"select * from tb_sosa s,tb_kliente k where s.id_kliente=k.id_kliente") or die ("".mysqli_error());
			while($row=mysqli_fetch_array($query))
				$data[]=$row;
			  return $data;
	}
    
    	function hare_sosa_tuir_fulantinan($fulan,$tinan){
			$con = mysqli_connect("localhost","root","");
            mysqli_select_db($con,"faan_karreta");
			$query=mysqli_query($con,"select * from tb_sosa s,tb_kliente k where s.id_kliente=k.id_kliente and month(data_sosa) ='$fulan' and year(data_sosa)='$tinan'") or die ("".mysqli_error());
			while($row=mysqli_fetch_array($query))
				$data[]=$row;
			  return $data;
	}
	
	
    function Rai_sosa($id_sosa,$id_kliente,$kuantidade,$preso,$data_sosa){
				$con = mysqli_connect("localhost","root","");
            mysqli_select_db($con,"faan_karreta");
			$query= mysqli_query($con,"INSERT into tb_sosa values('$id_sosa','$id_kliente','$kuantidade','$preso','$data_sosa')");
			return $query;
		}
		
		function Manipula_sosa($id_sosa){
			$con = mysqli_connect("localhost","root","");
            mysqli_select_db($con,"faan_karreta");
			$query=mysqli_query($con,"Select * from tb_sosa where id_sosa='$id_sosa'") or die ("".mysqli_error());
			while($row=mysqli_fetch_array($query))
				$data[]=$row;
			  return $data;
		}
		
			function update_sosa($id_sosa,$id_kliente,$kuantidade,$preso,$data_sosa){
			$con = mysqli_connect("localhost","root","");
            mysqli_select_db($con,"faan_karreta");
			$query= mysqli_query($con,"Update tb_sosa set id_kliente ='$id_kliente', kuantidade='$kuantidade',preso='$preso', data_sosa='$data_sosa' where id_sosa='$id_sosa'");
			return $query;
			
		}
		
		
				function Apaga_sosa($id_sosa) {
			$con = mysqli_connect("localhost","root","");
            mysqli_select_db($con,"faan_karreta");
			$query=mysqli_query($con,"DELETE FROM tb_sosa WHERE id_sosa='$id_sosa'") or die ("".mysqli_error());
			return $query;    
		}
        
        	function Opsaun_kliente() {
			$con = mysqli_connect("localhost","root","");
            mysqli_select_db($con,"faan_karreta");
			$query=mysqli_query($con,"select * from tb_kliente") or die ("".mysqli_error());
			return $query;    
		}
        
        
		
	
	}
	
	
	
	
      class gasto {
	function hare_gasto(){
			$con = mysqli_connect("localhost","root","");
            mysqli_select_db($con,"faan_karreta");
			$query=mysqli_query($con,"select * from tb_gasto s,tb_kategoria_gasto k where s.id_kategoria_gasto=k.id_kategoria_gasto") or die ("".mysqli_error());
			while($row=mysqli_fetch_array($query))
				$data[]=$row;
			  return $data;
	}
    
    	function hare_gasto_tuir_fulantinan($fulan,$tinan){
			$con = mysqli_connect("localhost","root","");
            mysqli_select_db($con,"faan_karreta");
			$query=mysqli_query($con,"select * from tb_gasto s,tb_kategoria_gasto k where s.id_kategoria_gasto=k.id_kategoria_gasto and month(data) ='$fulan' and year(data)='$tinan'") or die ("".mysqli_error());
			while($row=mysqli_fetch_array($query))
				$data[]=$row;
			  return $data;
	}
    

    
			function Rai_gasto($id_gasto,$discrisaun,$data,$osan,$id_kategoria_gasto){
				$con = mysqli_connect("localhost","root","");
            mysqli_select_db($con,"faan_karreta");
			$query= mysqli_query($con,"INSERT into tb_gasto values('$id_gasto','$discrisaun','$data','$osan','$id_kategoria_gasto')");
			return $query;
		}
		
		function Manipula_gasto($id_gasto){
			$con = mysqli_connect("localhost","root","");
            mysqli_select_db($con,"faan_karreta");
			$query=mysqli_query($con,"Select * from tb_gasto where id_gasto='$id_gasto'") or die ("".mysqli_error());
			while($row=mysqli_fetch_array($query))
				$data[]=$row;
			  return $data;
		}
		
			function update_gasto($id_gasto,$descrisaun,$data,$osan,$id_kategoria_gasto){
			$con = mysqli_connect("localhost","root","");
            mysqli_select_db($con,"faan_karreta");
			$query= mysqli_query($con,"Update tb_gasto set osan='$osan', deskrisaun ='$descrisaun', data='$data',id_kategoria_gasto='$id_kategoria_gasto' where id_gasto='$id_gasto'");
			return $query;
			
		}
		
		
				function Apaga_gasto($id_gasto) {
			$con = mysqli_connect("localhost","root","");
            mysqli_select_db($con,"faan_karreta");
			$query=mysqli_query($con,"DELETE FROM tb_gasto WHERE id_gasto='$id_gasto'") or die ("".mysqli_error());
			return $query;    
		}
        
        	function Opsaun_kategoria_gasto() {
			$con = mysqli_connect("localhost","root","");
            mysqli_select_db($con,"faan_karreta");
			$query=mysqli_query($con,"select * from tb_kategoria_gasto") or die ("".mysqli_error());
			return $query;    
		}
        
        
		
	
	}
	
	
	
	
	
		
	
	class login {
function login_utilizador($username,$password) {
			
		
$con = mysqli_connect("localhost","root","");
            mysqli_select_db($con,"faan_karreta");

//$kodigu_seguranca = sha1(md5($kodigu_seguranca));
			$result = mysqli_query($con,"select * from tb_utilizador  where username ='$username' and password='$password'") or die ("".mysqli_error());
			$user_data = mysqli_fetch_array($result);
			$no_rows = mysqli_num_rows($result);
			if ($no_rows == 1) {
				session_start();
				$_SESSION['username'] = TRUE;
			
	
				return TRUE;
			}
			else {
			  return FALSE;
			}
		}
        
        
        function troka_password($id_utilizador,$password) {
			
            	
					$con = mysqli_connect("localhost","root","");
            mysqli_select_db($con,"db_be");
			
			$query=mysqli_query($con,"Update tb_utilizador set kodigu_seguranca ='$password' where  id_utilizador='$id_utilizador'") or die ("".mysqli_error());
            
			return $query;    
		
		
		}
        
        
        
		
        
		
		
		
		
		
		
		
		
		
	}
?>