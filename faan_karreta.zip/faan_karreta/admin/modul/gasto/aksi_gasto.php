<?php
include'../../include/class.php';
$gasto = new gasto();
   
 if ($_POST['prosses']=='rai') {
 $rai_dados=$gasto->Rai_gasto($_POST['id_gasto'],$_POST['deskrisaun'],$_POST['data'],$_POST['osan'],$_POST['id_kategoria_gasto']);
 if($rai_dados) {
 header('location:../../aumenta_gasto_susesu.html');
  } else {
      header('location:../../aumenta_gasto_falla.html');
     }
   
}


if ($_POST['prosses']=='update') {
$update_dados=$gasto->update_gasto($_POST['id_gasto'],$_POST['deskrisaun'],$_POST['data'],$_POST['osan'],$_POST['id_kategoria_gasto']);
if($update_dados) {
header('location:../../update_gastos_susesu.html');
} 
}
                       
          if($_GET['proses']=="apaga"){
            //echo $_GET['id_konsumidor'];
    $apaga=$gasto->Apaga_gasto($_GET['id_gasto']);
    if($apaga){
	      header('location:../../apaga_gasto_susesu.html');
echo"a";
    }else{
	echo"apaga falha";

}
}

?>