
	<?php

$gasto = new gasto();
				 
echo"	<div class='col-md-12 content'>
<div class='panel panel-default'>
<div class='panel-heading'>
		<h4>Dados Gasto </h4>
</div>
	<div class='panel-body'>

<div class='table-toolbar'>
";
switch($_GET['act']){

default:
$mane1=0;
$feto1=0;
$nacional1=0;
$municipiu1=0;
$suku1=0;
$admin1=0;
if($_GET['info']=="aumenta_susesu"){echo "<div class='alert alert-alert alert-success'><h5>Dados  aumenta ho susesu </h5></div>";
}else if($_GET['info']=="aumenta_falla"){echo "<div class='alert alert-alert alert-warning'><h5>Dados Aumenta Fallha </h5></div>";
}else if($_GET['info']=="update_susesu"){echo "<div class='alert alert-alert alert-success'><h5>Dados update ho susesu </h5></div>";
}else if($_GET['info']=="apaga_susesu"){echo "<div class='alert alert-alert alert-success'><h5>Dados Apaga ho susesu </h5></div>";
}

echo"


<form class='form-horizontal'method='Post'action='' enctype='multipart/form-data'>
		

		            	<div class='form-group'>
				<label class='control-label col-sm-3' for='id_kategoria_gasto'>Fulan :</label>
				<div class='col-sm-6'>
					<select name='fulan' class='form-control'>
          
               <option value='1' > janeiru</option>
               <option value='2' > Fevereiru</option>
               <option value='3' > Marsu</option>
               <option value='4' > April</option>
               <option value='5' > Maio</option>
               <option value='6' > Junu</option>
               <option value='7' > Julhu</option>
               <option value='8' > Agostu</option>
               <option value='9' > Setembru</option>
               <option value='10' > October</option>
               <option value='11' > Novenbru</option>
               <option value='12' > Dezenbru</option>
                     </select>
	
				</div> 
			</div>

            
            
		            	<div class='form-group'>
				<label class='control-label col-sm-3' for='id_kategoria_gasto'> Tinan :</label>
				<div class='col-sm-6'>
					<select name='tinan' class='form-control'>
                    
                     <option value='2015'>2015</option>
                       <option value='2016'>2016</option>
                         <option value='2017'>2017</option>
                           <option value='2018'>2018</option>
                             <option value='2019'>2019</option>
                               <option value='2020'>2020</option>
                                  <option value='2021'>2021</option>
                             <option value='2022'>2022</option>
                               <option value='2023'>2023</option>
                     </select>
	
				</div> 
			</div>
			
			
			
				<center>
                <button type='submit' class='btn btn-success'name = 'hare'value ='dados'>Hare</button>	
			</center>
	
		</form>
        
        
<a href='aumenta_gasto.html'><button type='button' class='btn btn-primary'><span class='glyphicon glyphicon-plus'></span>&nbsp;Registu Gasto</button></a>




</center>
	</div><hr>
	<section id='no-more-tables'>

		<table class='table table-bordered table-striped table-bordered table-condensed'>

    <thead>
    <tr>
    <th>No</th>
    <th>id gasto</th>
	<th>Data</th>
    <th>Osan</th>
	<th>Kategoria Gastu</th>
	<th>Deskrisaun</th>
	<th>Asaun</th>

    </tr>
    </thead><tbody>";

$no=0;

if($_POST['hare']){
     $data = $gasto->hare_gasto_tuir_fulantinan($_POST['fulan'],$_POST['tinan']);  
    
}else{
 $data = $gasto->hare_gasto();   
}


$totosan = 0;

foreach ($data as $dados) {
$no++;
$No = $no;

$totosan = $totosan + $dados['osan'];

	echo"<tr>

	<td>$No</td>
	<td>$dados[id_gasto]</td>
	<td>$dados[data]</td>
      <td>$dados[osan]</td>
    <td>$dados[kategoria_gasto]</td>
	<td>$dados[deskrisaun]</td>
	

     <td><a href='manipula-gasto-$dados[id_gasto].html' data-toggle='tooltip' data-placement='left' title='Klik Iha nee Hodi Edit Dados Husi : $dados[actividade]'><button class='btn btn-primary btn-xs'><span class='glyphicon glyphicon-pencil'></button><span></a>
	<a href='modul/gasto/aksi_gasto.php?id_gasto=$dados[id_gasto]&proses=apaga'  data-toggle='tooltip' data-placement='left' title='Apaga' onclick=\"return confirm('ita boot hakarak atu apaga  dados gastu  : $dados[kategoria_gasto]')\"><button><span class='glyphicon glyphicon-trash'></span></button><span></a>

		 </td></tr>";
	
}
	echo "</tbody> <center><h4><b> Total Osan gasta hamutuk: $ $totosan </b></h4></center>  <br></table> </section>";

break;


case "aumenta":
echo"
		<h5 class='text-success text-center'><b>Registu Gasto</b></h5>
		<form class='form-horizontal'method='Post'action='modul/gasto/aksi_gasto.php' enctype='multipart/form-data'>
			<fieldset>
			

   <div class='form-group'>
				<label class='control-label col-sm-3' for='id_gasto'>Id Gasto :</label>
				<div class='col-sm-6'>
					<input type='text' name='id_gasto' class='form-control'/>
				</div>
			</div>
			

 <div class='form-group'>
				<label class='control-label col-sm-3' for='deskrisaun'>Deskrisaun :</label>
				<div class='col-sm-6'>
					<input type='text' name='deskrisaun' class='form-control'/>
									</div>
			</div>
			
 <div class='form-group'>
				<label class='control-label col-sm-3' for='data'>Data :</label>
				<div class='col-sm-6'>
					<input type='text' name='data' class='form-control'/>

				</div>  
			</div>
            
            
            			
 <div class='form-group'>
				<label class='control-label col-sm-3' for='data'>Osan :</label>
				<div class='col-sm-6'>
					<input type='text' name='osan' class='form-control'/>

				</div>  
			</div>
			
		            	<div class='form-group'>
				<label class='control-label col-sm-3' for='id_kategoria_gasto'>Hili Kaegoria  gasto :</label>
				<div class='col-sm-6'>
					<select name='id_kategoria_gasto' class='form-control'>
					";
$data = $gasto->Opsaun_kategoria_gasto();
foreach ($data as $dados) {

echo "<option value='$dados[id_kategoria_gasto]' selected>$dados[kategoria_gasto]</option>";
    
}
echo"
</select>
		
				</div> 
			</div>

			
			
			
				
			<div class='form-group'>
				<div class='col-sm-offset-2 col-sm-10'>
					<button type='submit' class='btn btn-success'name = 'prosses'value ='rai'>Registo</button>
					
					<a href='gasto.html'><button type='button' class='btn btn-warning'>Fila</button></a>
				</div>
			</div>
			
			</div>
			</div>
		
			</fieldset>
		</form>
	</div>
	
  
";


break;
case 'manipula':

$data = $gasto->Manipula_gasto($_GET['id_gasto']);

foreach ($data as $dados) {
	
	$edit_id_gasto = $dados['id_gasto'];
    $edit_deskrisaun = $dados['deskrisaun'];
	$edit_data = $dados['data'];
	$edit_id_kategoria_gasto = $dados['id_kategoria_gasto'];
    $edit_osan = $dados['osan'];



}

echo"
		<h5 class='text-success text-center'><b>Registu Gasto</b></h5>
		<form class='form-horizontal'method='Post'action='modul/gasto/aksi_gasto.php' enctype='multipart/form-data'>
			<fieldset>
			

   <div class='form-group'>
				<label class='control-label col-sm-3' for='id_gasto'>Id Gasto :</label>
				<div class='col-sm-6'>
					<input type='text' name='id_gasto'value='$edit_id_gasto' class='form-control'/>
				</div>
			</div>
			

 
			</div><div class='form-group'>
				<label class='control-label col-sm-3' for='deskrisaun'>Deskrisaun :</label>
				<div class='col-sm-6'>
					<input type='text' value='$edit_deskrisaun' name='deskrisaun' class='form-control'/>
				</div>
				</div>
			
		
 <div class='form-group'>
				<label class='control-label col-sm-3' for='data'>Data :</label>
				<div class='col-sm-6'>
					<input type='text' name='data' value='$edit_data' class='form-control'/>
				</div>  
			</div>

            
             <div class='form-group'>
				<label class='control-label col-sm-3' for='data'>Osan :</label>
				<div class='col-sm-6'>
					<input type='text' name='osan' value='$edit_osan' class='form-control'/>
				</div>  
			</div>
			
		            	<div class='form-group'>
				<label class='control-label col-sm-3' for='id_kategoria_gasto'>Hili Kaegoria  gasto :</label>
				<div class='col-sm-6'>
					<select name='id_kategoria_gasto' class='form-control'>
					";
$data = $gasto->Opsaun_kategoria_gasto();
foreach ($data as $dados) {
if($Edit_id_kategoria_gasto =="$Dados[id_kategoria_gasto]"){
 echo "<option value='$dados[id_kategoria_gasto]' selected>$dados[kategoria_gasto]</option>";   
}else{
echo "<option value='$dados[id_kategoria_gasto]' >$dados[kategoria_gasto]</option>";
} 
}
echo"
</select>
		
				</div> 
			</div>

			
			
			
				
			<div class='form-group'>
				<div class='col-sm-offset-2 col-sm-10'>
					<button type='submit' class='btn btn-success'name = 'prosses'value ='update'>Registo</button>
					
					<a href='gasto.html'><button type='button' class='btn btn-warning'>Fila</button></a>
				</div>
			</div>
			
			</div>
			</div>
		
			</fieldset>
		</form>
	</div>
	
  
";

break;

}
echo"</div></div></div>";