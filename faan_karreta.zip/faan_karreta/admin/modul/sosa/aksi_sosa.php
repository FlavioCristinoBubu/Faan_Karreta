<?php
error_reporting();
include'../../include/class.php';
$sosa = new sosa();

if($_POST['prosses']=='rai') {
   $rai_dados=$sosa->Rai_sosa($_POST['id_sosa'],$_POST['id_kliente'],$_POST['kuantidade'],$_POST['preso'],$_POST['data_sosa']);
 if($rai_dados) {
 header('location:../../aumenta_sosa_susesu.html');
  } else {
      header('location:../../aumenta_sosa_falla.html');
     }   
}

          
if($_POST['prosses']=="update") {
$update_dados=$sosa->update_sosa($_POST['id_sosa'],$_POST['id_kliente'],$_POST['kuantidade'],$_POST['preso'],$_POST['data_sosa']);
if($update_dados) {
      header('location:../../apaga_sosa_susesu.html');
 } 
 }
          
         if($_GET['proses']=="apaga"){
  echo $_GET['id_sosa'];
    $apaga=$sosa->Apaga_sosa($_GET['id_sosa']);
    if($apaga){
        header('location:../../apaga_sosa_susesu.html');
echo"a";
    }else{
       echo"apaga falha";
}
}            
?>


