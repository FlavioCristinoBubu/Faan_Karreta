	<?php
error_reporting();
$sosa = new sosa();



				 
echo"	<div class='col-md-12 content'>
<div class='panel panel-default'>
<div class='panel-heading'>
		<h4>Dados Sosa</h4>
</div>
	<div class='panel-body'>

<div class='table-toolbar'>
";
switch($_GET['act']){

default:
$mane1=0;
$feto1=0;
$nacional1=0;
$municipiu1=0;
$suku1=0;
$admin1=0;
if($_GET['info']=="aumenta_susesu"){echo "<div class='alert alert-alert alert-success'><h5>Dados  aumenta ho susesu </h5></div>";
}else if($_GET['info']=="aumenta_falla"){echo "<div class='alert alert-alert alert-warning'><h5>Dados Aumenta Fallha </h5></div>";
}else if($_GET['info']=="apaga_susesu"){echo "<div class='alert alert-alert alert-success'><h5>Dados apaga ho susesu</h5></div>";
}else if($_GET['info']=="update_susesu"){echo "<div class='alert alert-alert alert-success'><h5>Dados update ho susesu </h5></div>";
}

echo"

<form class='form-horizontal'method='Post'action='' enctype='multipart/form-data'>
		

		            	<div class='form-group'>
				<label class='control-label col-sm-3' for='id_kliente'>Fulan :</label>
				<div class='col-sm-6'>
					<select name='fulan' class='form-control'>
          
               <option value='1' > janeiru</option>
               <option value='2' > Fevereiru</option>
               <option value='3' > Marsu</option>
               <option value='4' > April</option>
               <option value='5' > Maio</option>
               <option value='6' > Junu</option>
               <option value='7' > Julhu</option>
               <option value='8' > Agostu</option>
               <option value='9' > Setembru</option>
               <option value='10' > October</option>
               <option value='11' > Novenbru</option>
               <option value='12' > Dezenbru</option>
                     </select>
	
				</div> 
			</div>

            
            
		            	<div class='form-group'>
				<label class='control-label col-sm-3' for='id_kliente'> Tinan :</label>
				<div class='col-sm-6'>
					<select name='tinan' class='form-control'>
                    
                     <option value='2015'>2015</option>
                       <option value='2016'>2016</option>
                         <option value='2017'>2017</option>
                           <option value='2018'>2018</option>
                             <option value='2019'>2019</option>
                               <option value='2020'>2020</option>
                                  <option value='2021'>2021</option>
                             <option value='2022'>2022</option>
                               <option value='2023'>2023</option>
							   <option value='2024'>2024</option>

                     </select>
	
				</div> 
			</div>
			
			
			
				<center>
                <button type='submit' class='btn btn-success'name = 'hare'value ='dados'>Hare</button>	
			</center>
			
		</form>
        
        
<a href='aumenta_sosa.html'><button type='button' class='btn btn-primary'><span class='glyphicon glyphicon-plus'></span>&nbsp;Registu osan-tama</button></a>


</center>
	</div><hr>
	<section id='no-more-tables'>

		<table class='table table-bordered table-striped table-bordered table-condensed'>

    <thead>
    <tr>
    <th>No</th>
	<th>Naran Kliente</th>
	<th>Kuantidade</th>
	<th>Presu</th>
    <th>Data Sosa</th>
	<th>AKSAUN</th>
    </tr>
    </thead><tbody>";
if($_POST['hare']){
     $data = $sosa->hare_sosa_tuir_fulantinan($_POST['fulan'],$_POST['tinan']);  
    
}else{
$data = $sosa->hare_sosa(); 
}

$no=0;

$totosan = 0;

foreach ($data as $dados) {
$no++;
$No = $no;

$totosan = $totosan + $dados['preso'];
	echo"<tr>

	<td>$No</td>
	<td>$dados[id_kliente] - $dados[naran_kliente]</td>
	<td>$dados[kuantidade]</td>
	<td>$dados[preso]</td>
    <td>$dados[data_sosa]</td>
	
	
     <td><a href='manipula-sosa-$dados[id_sosa].html' data-toggle='tooltip' data-placement='left' title='Klik Iha nee Hodi Edit Dados Husi : $dados[actividade]'><button class='btn btn-primary btn-xs'><span class='glyphicon glyphicon-pencil'></button><span></a>
	<a href='modul/sosa/aksi_sosa.php?id_sosa=$dados[id_sosa]&proses=apaga'  data-toggle='tooltip' data-placement='left' title='Apaga' onclick=\"return confirm('ita boot hakarak atu apaga dados sosa husi : $dados[naran_kliente]')\"><button><span class='glyphicon glyphicon-trash'></span></button><span></a>

		 </td></tr>";
	
}
	echo "</tbody> <center><h4><b> Total Osan tama hamutuk: $ $totosan </b></h4></center> <br> </table></section>";

break;


case "aumenta":
echo"

	    <h5 class='text-success text-center'><b>Registu osan-tama</b></h5>
		<form class='form-horizontal' method='Post' action='modul/sosa/aksi_sosa.php'  enctype='multipart/form-data'>
			<fieldset>
			

   <div class='form-group'>
				<label class='control-label col-sm-3' for='id_sosa'> id-sosa :</label>
				<div class='col-sm-6'>
					<input type='text' name='id_sosa' placeholder='id_sosa' class='form-control' />
				</div>
			</div>

				<div class='form-group'>
				<label class='control-label col-sm-3' for='kuantidade'>kuantidade :</label>
				<div class='col-sm-6'>
					<input type='text' placeholder='kuantidade' name='kuantidade' class='form-control' />
				</div>
				</div>
			
			
			<div class='form-group'>
				<label class='control-label col-sm-3' for='preso'>preso:</label>
				<div class='col-sm-6'>
					<input type='text' name='preso' placeholder='preso' class='form-control'  />
			</div>  
			</div>

			 <div class='form-group'>
				<label class='control-label col-sm-3' for='data_sosa'>data_sosa :</label>
				<div class='col-sm-6'>
					<input type='text' name='data_sosa' placeholder='data-sosa' class='form-control'  />
			</div>  
			</div>
			

            	<div class='form-group'>
				<label class='control-label col-sm-3' for='id_kliente'>Hili kliente:</label>
				<div class='col-sm-6'>
					<select name='id_kliente' class='form-control'>
					<div class='form-group'>
				<div class='col-sm-offset-2 col-sm-10'>
					<button type='submit' class='btn btn-success'name = 'prosses' value='rai'>Registo</button>
					
					<a href='estudante.html'><button type='button' class='btn btn-warning'>Fila</button></a>
				</div>
			</div>
			
		
			</fieldset>
		</form>
	</div>

					";

$data = $sosa->Opsaun_kliente();
foreach ($data as $dados) {
echo "<option value='$dados[id_kliente]' selected>$dados[naran_kliente]</option>";
}
echo"
</select>
		
				</div> 
			</div>

			
			
				
			<div class='form-group'>
				<div class='col-sm-offset-2 col-sm-10'>
					<button type='submit' class='btn btn-success'name = 'prosses'value ='rai'>Registo</button>
					
					<a href='sosa.html'><button type='button' class='btn btn-warning'>Fila</button></a>
				</div>
			</div>
			
		
			</fieldset>
		</form>
	</div>
	
  
";


break;
case 'manipula':

$data = $sosa->Manipula_sosa($_GET['id_sosa']);

foreach ($data as $dados) {
	
	$edit_id_sosa = $dados['id_sosa'];
    $edit_id_kliente = $dados['id_kliente'];
	$edit_kuantidade = $dados['kuantidade'];
	$edit_preso = $dados['preso'];
    $edit_data_sosa = $dados['data_sosa'];



}
echo"
	    <h5 class='text-success text-center'><b>Registu Sosa</b></h5>
		<form class='form-horizontal' method='Post' action='modul/sosa/aksi_sosa.php'  enctype='multipart/form-data'>
			<fieldset>
			

   <div class='form-group'>
				<label class='control-label col-sm-3' for='id_sosa'>id-sosa :</label>
				<div class='col-sm-6'>
					<input type='text' name='id_sosa' placeholder='id_sosa' class='form-control'/>
				</div>
			</div>

				<div class='form-group'>
				<label class='control-label col-sm-3' for='id-kliente'>id-kliente</label>
				<div class='col-sm-6'>
					<input type='text' placeholder='id_kliente' name='id_kliente' class='form-control'/>
				</div>
				</div>
			
			
			<div class='form-group'>
				<label class='control-label col-sm-3' for='kuantidade'>kuantidade</label>
				<div class='col-sm-6'>
					<input type='text' placeholder='kuantidade' name='kuantidade' class='form-control'/>
				</div>
				</div>
			 <div class='form-group'>
				<label class='control-label col-sm-3' for='preso'>preso</label>
				<div class='col-sm-6'>
					<input type='text' placeholder='preso' name='preso' class='form-control'/>
				</div>
				</div>

				<div class='form-group'>
				<label class='control-label col-sm-3' for='data_sosa'>data_sosa</label>
				<div class='col-sm-6'>
					<input type='text' placeholder='data_sosa' name='data_sosa' class='form-control'/>
				</div>
				</div>
			
            	<div class='form-group'>
				<label class='control-label col-sm-3' for='id_kliente'>Hili kliente :</label>
				<div class='col-sm-6'>
					<select name='id_kliente' class='form-control'>
					";
$data = $sosa->Opsaun_kliente();
foreach ($data as $dados) {
if($dados['id_kliente']=="$edit_id_kliente"){
echo "<option value='$dados[id_kliente]' selected=>$dados[naran_kliente]</option>";
    }else{
echo "<option value='$dados[id_kliente]' >$dados[naran_kliente]</option>";
    }
}
echo"
</select>
		
				</div> 
			</div>

			
				
			<div class='form-group'>
				<div class='col-sm-offset-2 col-sm-10'>
					<button type='submit' class='btn btn-success'name = 'prosses' value='updates'>Registo</button>
					
					<a href='sosa.html'><button type='button' class='btn btn-warning'>Fila</button></a>
				</div>
			</div>
			
			</div>
			</div>
		
			</fieldset>
		</form>
	</div>
	
  
";
break;

}
echo"</div></div></div>";