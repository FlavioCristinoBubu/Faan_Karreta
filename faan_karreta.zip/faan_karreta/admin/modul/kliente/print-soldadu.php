<html>
<body onLoad="window.print();">

   <style type="text/css">
body {
	font-size:12px;
	font-family:Arial, Helvetica, sans-serif;
}
.style1{
	font-size:12px;
	font-family:Arial, Helvetica, sans-serif;
}
</style>
<p align="center">RELATORIU DADUS SOLDADU</p>
  <table width="100%" cellspacing="0" cellpadding="2" border="1px" class="style1">
   	      
  <tr>
    <th width="5%" align="center" class="style1" bgcolor="#CCCCCC">No</th>
   	<th width="13%" align="center" class="style1" bgcolor="#CCCCCC">NARAN</th>
   	<th width="26%" align="center" class="style1" bgcolor="#CCCCCC">SEXU</th>
    <th width="14%" align="center" class="style1" bgcolor="#CCCCCC">ENDERESU</th>
    <th width="11%" align="center" class="style1" bgcolor="#CCCCCC">MUNICIPIU</th>
    <!-- <th width="9%" align="center" class="style1" bgcolor="#CCCCCC">Jns Kelamin</th> -->
   <!--  <th width="14%" align="center" class="style1" bgcolor="#CCCCCC">Prodi</th>
   	<th width="8%" align="center" class="style1" bgcolor="#CCCCCC">Thn Masuk</th> -->
  </tr>
          
  <?php
  // include_once 'inc/class.perpus.php';
  include_once 'include/class.php';
  $anggota = new anggota;
	$query = "SELECT  naran,sexu,enderesu,municipiu FROM tb_soldadu_negro  s, db_municipiu m where s.id_municipiu=m.id_municipiu ORDER by id_soldadu";  
	$no = 1;
				
				foreach ($anggota->showData($query) as $data) {
			?>
   	        <tbody>
   	          <tr>
   	            <td align="center"><?php echo $no; ?></td>
<!--    	            <td ><?php echo $data['nim']; ?></td>
   	            <td ><?php echo $data['nama']; ?></td> -->
                <td align="center"><?php echo $data['naran']; ?></td>
                <td align="center"><?php echo $data['sexu']; ?></td>
                <td align="center"><?php echo $data['enderesu']; ?></td>                
                <td align="center"><?php echo $data['municipiu']; ?></td>
   	            <!-- <td align="center"><?php echo $data['thn_masuk']; ?></td> -->
                
              </tr>
              
      <?php $no++; } ?>
           
    </tbody>
</table>
          
</body>
</html>