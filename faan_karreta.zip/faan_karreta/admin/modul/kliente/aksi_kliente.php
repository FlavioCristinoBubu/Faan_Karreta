<?php
include'../../include/class.php';
$kliente = new kliente();


   
 if ($_POST['prosses']=='rai') {
 $rai_dados=$kliente->Rai_kliente($_POST['id_kliente'],$_POST['naran_kliente'],$_POST['kontak'],$_POST['kategorio_kliente']);
 if($rai_dados) {
 header('location:../../aumenta_kliente_susesu.html');
  } else {
      header('location:../../aumenta_kliente_falla.html');
     }
   
}





if($_POST['prosses']=="update") {
$update_dados=$kliente->update_kliente($_POST['id_kliente'],$_POST['naran_kliente'],$_POST['kontak'],$_POST['kategorio_kliente']);
if($update_dados) {
      header('location:../../apaga_sosa_susesu.html');
                             } else { echo"$_POST[id_kliente],$_POST[naran_kliente],$_POST[kontak],$_POST[kategorio_kliente]"; 



                     }
					   
					   }
                       
           if($_GET['proses']=="apaga"){
  echo $_GET['id_kliente'];
    $apaga=$kliente->Apaga_kliente($_GET['id_kliente']);
    if($apaga){
        header('location:../../apaga_kliente_susesu.html');
echo"a";
    }else{
  echo"apaga falha";

}
}

?>