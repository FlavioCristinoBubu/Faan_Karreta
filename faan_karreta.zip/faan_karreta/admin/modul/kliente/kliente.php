	<?php

$kliente = new kliente();



				 
echo"	<div class='col-md-12 content'>
<div class='panel panel-default'>
<div class='panel-heading'>
		<h4>Dados kliente</h4>
</div>
	<div class='panel-body'>

<div class='table-toolbar'>
";
switch($_GET['act']){

default:
$mane1=0;
$feto1=0;
$nacional1=0;
$municipiu1=0;
$suku1=0;
$admin1=0;
if($_GET['info']=="aumenta_susesu"){echo "<div class='alert alert-alert alert-success'><h5>Dados  aumenta ho susesu </h5></div>";
}else if($_GET['info']=="aumenta_falla"){echo "<div class='alert alert-alert alert-warning'><h5>Dados Aumenta Fallha </h5></div>";
}else if($_GET['info']=="apaga_susesu"){echo "<div class='alert alert-alert alert-success'><h5>Dados apaga ho susesu </h5></div>";
}else if($_GET['info']=="registo_susesu"){echo "<div class='alert alert-alert alert-success'><h5>>Dados update ho susesu </h5></div>";
}

echo"
<a href='aumenta_kliente.html'><button type='button' class='btn btn-primary'><span class='glyphicon glyphicon-plus'></span>&nbsp;Registu kliente</button></a>

</center>
	</div><hr>
	<section id='no-more-tables'>

		<table class='table table-bordered table-striped table-bordered table-condensed'>

    <thead>
    <tr>
    <th>No</th>
	<th>Naran</th>
	<th>kontak</th>
	<th>Id kategoria</th>


	
	<th>AKSAUN</th>
    </tr>
    </thead><tbody>";

$no=0;
$data = $kliente->hare_kliente();
foreach ($data as $dados) {
$no++;
$No = $no;



	echo"<tr>

	<td>$No</td>
	<td>$dados[naran_kliente]</td>
	<td>$dados[kontak]</td>
	<td>$dados[kategorio_kliente]</td>
	
	
     <td><a href='manipula-kliente-$dados[id_kliente].html' data-toggle='tooltip' data-placement='left' title='Klik Iha nee Hodi Edit Dados Husi : $dados[actividade]'><button class='btn btn-primary btn-xs'><span class='glyphicon glyphicon-pencil'></button><span></a>
	<a href='modul/kliente/aksi_kliente.php?id_kliente=$dados[id_kliente]&proses=apaga'  data-toggle='tooltip' data-placement='left' title='Apaga' onclick=\"return confirm('ita boot hakarak atu apaga  kliente : $dados[naran_kliente]')\"><button><span class='glyphicon glyphicon-trash'></span></button><span></a>

		 </td></tr>";
	
}
	echo "</tbody></table></section>";

break;


case "aumenta":
echo"
		<h5 class='text-success text-center'><b>Registu kliente</b></h5>
		<form class='form-horizontal'method='Post'action='modul/kliente/aksi_kliente.php' enctype='multipart/form-data'>
			<fieldset>
			

   <div class='form-group'>
				<label class='control-label col-sm-3' for='no_emis'>Id kliente :</label>
				<div class='col-sm-6'>
					<input type='text' name='id_kliente' class='form-control' />
				</div>
			</div>
			

 <div class='form-group'>
				<label class='control-label col-sm-3' for='naran_kliente'>Naran kliente :</label>
				<div class='col-sm-6'>
					<input type='text' name='naran_kliente' class='form-control' />
									</div>
			</div>
			
 <div class='form-group'>
				<label class='control-label col-sm-3' for='kontak'>Kontak :</label>
				<div class='col-sm-6'>
					<input type='text' name='kontak' class='form-control'  />

				</div>  
			</div>
			
			 <div class='form-group'>
				<label class='control-label col-sm-3' for='kategorio_kliente'>Kategoria kliente :</label>
				<div class='col-sm-6'>
                <select name ='kategorio_kliente' class= 'form-control'>
				<option value='P'> Person</option>
                <option value='O'> Intituisaun/organizasaun</option>
                </select>
	
				</div>
			</div>
			
			
			
				
			<div class='form-group'>
				<div class='col-sm-offset-2 col-sm-10'>
					<button type='submit' class='btn btn-success'name = 'prosses'value ='rai'>Registo</button>
					
					<a href='kliente.html'><button type='button' class='btn btn-warning'>Fila</button></a>
				</div>
			</div>
			
			</div>
			</div>
		
			</fieldset>
		</form>
	</div>
	
  
";


break;
case 'manipula':

$data = $kliente->Manipula_kliente($_GET['id_kliente']);

foreach ($data as $dados) {
	
	$edit_id_kliente = $dados['id_kliente'];
    $edit_naran_kliente = $dados['naran_kliente'];
	$edit_kontak = $dados['kontak'];
	$edit_kategorio_kliente = $dados['kategorio_kliente'];



}
echo"
		<h5 class='text-success text-center'><b>Registo Dados kliente</b></h5>
		<form class='form-horizontal'method='Post'action='modul/kliente/aksi_kliente.php' enctype='multipart/form-data'>
		 	<fieldset>
			

   <div class='form-group'>
				<label class='control-label col-sm-3' for='no_emis'>Id kliente :</label>
				<div class='col-sm-6'>
					<input type='text' name='id_kliente'  value='$edit_id_kliente' class='form-control' />
				</div>
			</div>
			

 <div class='form-group'>
				<label class='control-label col-sm-3' for='naran_kliente'>Naran kliente :</label>
				<div class='col-sm-6'>
					<input type='text' name='naran_kliente' value='$edit_naran_kliente' class='form-control' />
									</div>
			</div>
			
 <div class='form-group'>
				<label class='control-label col-sm-3' for='kontak'>Kontak :</label>
				<div class='col-sm-6'>
					<input type='text' name='kontak' value='$edit_kontak' class='form-control'  />

				</div>  
			</div>
			
			 <div class='form-group'>
				<label class='control-label col-sm-3' for='kategorio_kliente'>Kategoria kliente :</label>
				<div class='col-sm-6'>
                <select name ='kategorio_kliente' class= 'form-control'>
				<option value='P'> Person</option>
                <option value='O'> Intituisaun/organizasaun</option>
                </select>
	
				</div>
			</div>
			
			
			
				
			<div class='form-group'>
				<div class='col-sm-offset-2 col-sm-10'>
					<button type='submit' class='btn btn-success'name = 'prosses'value ='update'>Registo</button>
					
					<a href='kliente.html'><button type='button' class='btn btn-warning'>Fila</button></a>
				</div>
			</div>
			
			</div>
			</div>
		
			</fieldset>
		</form>
	</div>
	
  
";
break;

}
echo"</div></div></div>";