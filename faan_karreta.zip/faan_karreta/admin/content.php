<?php
//Content ba Utilizador No Admin

if ($_GET['pagina']=='kliente'){
  include "modul/kliente/kliente.php";
}
elseif ($_GET['pagina']=='sosa'){
   include "modul/sosa/sosa.php";
}
elseif ($_GET['pagina']=='gasto'){
   include "modul/gasto/gasto.php";
}
elseif ($_GET['pagina']=='grafiku'){
  include "../grafiku/grafiku_departamento.php";
}
elseif ($_GET['pagina']=='relatorio'){
  include "modul/relatorio/index.php";

}else{
//Mesagen Venvindu Ba Utilizador Nebe Login
 echo "

 <div class='col-lg-12'>
	<center><h1>Benvindu sistema :<br>
	<small>Gestaun Orsamentu Faan Karreta</small></h1></center>
 
	  </div></div>";

   
 

 
}





?>



