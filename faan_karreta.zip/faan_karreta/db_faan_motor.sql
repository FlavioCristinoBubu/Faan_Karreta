-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 03, 2020 at 04:53 PM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_faan_motor`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_gasto`
--

CREATE TABLE IF NOT EXISTS `tb_gasto` (
  `id_gasto` int(6) NOT NULL,
  `deskrisaun` text NOT NULL,
  `data` date NOT NULL,
  `osan` varchar(50) NOT NULL,
  `id_kategoria_gasto` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_gasto`
--

INSERT INTO `tb_gasto` (`id_gasto`, `deskrisaun`, `data`, `osan`, `id_kategoria_gasto`) VALUES
(0, 'segunda_feira', '2020-06-01', '11', 2),
(1, 'terca_feira', '2020-07-02', '90', 1),
(6, 'bbbbbbb', '2019-02-01', '7', 2),
(88, 'gasta selu sr domingus nia servisu', '2019-02-01', '9', 3),
(101, 'hola masaco', '2019-02-01', '55', 1),
(102, 'selu sr nia salario', '2019-04-01', '200', 3),
(103, 'gasta hola mina', '2020-05-01', '0.50', 3);

-- --------------------------------------------------------

--
-- Table structure for table `tb_kategoria_gasto`
--

CREATE TABLE IF NOT EXISTS `tb_kategoria_gasto` (
  `id_kategoria_gasto` int(1) NOT NULL,
  `kategoria_gasto` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_kategoria_gasto`
--

INSERT INTO `tb_kategoria_gasto` (`id_kategoria_gasto`, `kategoria_gasto`) VALUES
(0, 'seluk'),
(1, 'Gasto ba sosa motor '),
(2, 'Gasto hola hahan ba kliente'),
(3, 'Gastu hola motor nia alat sira'),
(4, 'seluk');

-- --------------------------------------------------------

--
-- Table structure for table `tb_kliente`
--

CREATE TABLE IF NOT EXISTS `tb_kliente` (
  `id_kliente` int(6) NOT NULL,
  `naran_kliente` varchar(50) NOT NULL,
  `kontak` char(30) NOT NULL,
  `kategorio_kliente` enum('P','O') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_kliente`
--

INSERT INTO `tb_kliente` (`id_kliente`, `naran_kliente`, `kontak`, `kategorio_kliente`) VALUES
(1, 'Domingos', '+67037753016', 'P'),
(2, 'Domingos da costa', '+67037753016', 'P'),
(3, 'julia da costa', '+67075940372', 'P'),
(4, 'maria auxiliadora de fatima', '+67076589484', 'P'),
(8, 'koko', '88', 'O'),
(9, 'Labeh', '778777', 'O'),
(19, 'Maria', '+4635753', 'O');

-- --------------------------------------------------------

--
-- Table structure for table `tb_sosa`
--

CREATE TABLE IF NOT EXISTS `tb_sosa` (
  `id_sosa` int(3) NOT NULL,
  `id_kliente` int(6) NOT NULL,
  `kuantidade` int(3) NOT NULL,
  `preso` double NOT NULL,
  `data_sosa` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_sosa`
--

INSERT INTO `tb_sosa` (`id_sosa`, `id_kliente`, `kuantidade`, `preso`, `data_sosa`) VALUES
(2, 2, 1, 400, '2020-07-08'),
(22, 2, 44, 22, '2020-01-01'),
(23, 2, 44, 66, '2020-01-01'),
(99, 1, 66, 66, '2020-01-01'),
(100, 9, 10, 99, '2020-01-01'),
(200, 4, 66, 66, '2020-01-01');

-- --------------------------------------------------------

--
-- Table structure for table `tb_utilizador`
--

CREATE TABLE IF NOT EXISTS `tb_utilizador` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_utilizador`
--

INSERT INTO `tb_utilizador` (`username`, `password`) VALUES
('admin', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_gasto`
--
ALTER TABLE `tb_gasto`
 ADD PRIMARY KEY (`id_gasto`), ADD KEY `id_kategoria_Gasta` (`id_kategoria_gasto`);

--
-- Indexes for table `tb_kategoria_gasto`
--
ALTER TABLE `tb_kategoria_gasto`
 ADD PRIMARY KEY (`id_kategoria_gasto`);

--
-- Indexes for table `tb_kliente`
--
ALTER TABLE `tb_kliente`
 ADD PRIMARY KEY (`id_kliente`);

--
-- Indexes for table `tb_sosa`
--
ALTER TABLE `tb_sosa`
 ADD PRIMARY KEY (`id_sosa`), ADD KEY `id_Konsumidor` (`id_kliente`);

--
-- Indexes for table `tb_utilizador`
--
ALTER TABLE `tb_utilizador`
 ADD PRIMARY KEY (`username`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tb_gasto`
--
ALTER TABLE `tb_gasto`
ADD CONSTRAINT `tb_gasto_ibfk_1` FOREIGN KEY (`id_kategoria_gasto`) REFERENCES `tb_kategoria_gasto` (`id_kategoria_gasto`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
